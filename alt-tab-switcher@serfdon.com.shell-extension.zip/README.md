# 3D & Wall Alt-Tab Switcher for GNOME Shell

A custom ES-module Alt-Tab window switcher for GNOME Shell (50 and 51) featuring **8 distinct visual layouts** and **8 independent per-layout themes**.

## Layouts
1. **Wall** — Responsive dynamic window grid
2. **Carousel 1 (3D Cylinder Strip)** — Smoothly orbiting 3D paper-strip drum
3. **Carousel 2 (3D CoverFlow Stage)** — Center spotlight with angled side wings
4. **Poker Hand Fan** — Curved radial card fan with elevated active window
5. **Card Toss** — Center stack that flicks dismissed windows off-screen
6. **Spin-Swap** — 360° cross-screen spin transitions
7. **Depth Tunnel** — Z-axis zoom corridor
8. **Rolodex** — Compact vertical 3D flip wheel

## Per-Layout Themes
- Frosted Glass
- Classic High-Contrast
- Neon Cyan
- Neon Red
- Neon Lime
- Pink Rose
- Forest Green
- Royal Purple

